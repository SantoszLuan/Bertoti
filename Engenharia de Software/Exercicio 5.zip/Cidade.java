public class Cidade {
    private String nome;
    private int populacao;
    private double longitude;

    public Cidade(String nome, int populacao, double longitude) {
        this.nome = nome;
        this.populacao = populacao;
        this.longitude = longitude;
    }

    public void coletarImpostos() {
        System.out.println("A cidade de " + nome + " está coletando impostos.");
    }

    public void organizar() {
        System.out.println("A cidade de " + nome + " está sendo organizada.");
    }

    public void limpar() {
        System.out.println("As ruas da cidade de " + nome + " estão sendo limpas.");
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public int getPopulacao() { return populacao; }
    public void setPopulacao(int populacao) { this.populacao = populacao; }

    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
}
