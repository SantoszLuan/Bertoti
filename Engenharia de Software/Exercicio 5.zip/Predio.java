public class Predio {
    private String cor;
    private double altura;
    private int andares;

    public Predio(String cor, double altura, int andares) {
        this.cor = cor;
        this.altura = altura;
        this.andares = andares;
    }

    public void subirAndares(int quantidade) {
        System.out.println("Subindo " + quantidade + " andares...");
    }

    public void acenderLuzes() {
        System.out.println("As luzes do prédio foram acesas.");
    }

    public void apagarLuzes() {
        System.out.println("As luzes do prédio foram apagadas.");
    }

    public String getCor() { return cor; }
    public void setCor(String cor) { this.cor = cor; }

    public double getAltura() { return altura; }
    public void setAltura(double altura) { this.altura = altura; }

    public int getAndares() { return andares; }
    public void setAndares(int andares) { this.andares = andares; }
}
