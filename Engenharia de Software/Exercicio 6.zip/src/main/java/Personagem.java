public class Personagem {
    private String nome;
    private int idade;
    private String sexo;

    public Personagem(String nome, int idade, String sexo) {
        this.nome = nome;
        this.idade = idade;
        this.sexo = sexo;
    }

    public void conversar() {
        System.out.println(nome + " está conversando.");
    }

    public void segurarMao() {
        System.out.println(nome + " está segurando a mão de alguém.");
    }

    public void refletir() {
        System.out.println(nome + " está refletindo sobre a vida.");
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public int getIdade() { return idade; }
    public void setIdade(int idade) { this.idade = idade; }

    public String getSexo() { return sexo; }
    public void setSexo(String sexo) { this.sexo = sexo; }
}
