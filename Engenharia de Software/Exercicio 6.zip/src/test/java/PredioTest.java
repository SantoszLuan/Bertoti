import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PredioTest {

    private Predio predio;

    @BeforeEach
    void setUp() {
        predio = new Predio("Azul", 100.5, 20);
    }

    @Test
    void testAtributosIniciais() {
        assertEquals("Azul", predio.getCor());
        assertEquals(100.5, predio.getAltura());
        assertEquals(20, predio.getAndares());
    }

    @Test
    void testAlterarAltura() {
        predio.setAltura(120.0);
        assertEquals(120.0, predio.getAltura());
    }

    @Test
    void testMetodosNaoGeramErro() {
        assertDoesNotThrow(() -> predio.subirAndares(5));
        assertDoesNotThrow(() -> predio.acenderLuzes());
        assertDoesNotThrow(() -> predio.apagarLuzes());
    }
}
