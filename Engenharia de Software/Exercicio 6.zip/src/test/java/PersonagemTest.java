import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PersonagemTest {

    private Personagem personagem;

    @BeforeEach
    void setUp() {
        personagem = new Personagem("Luan", 25, "Masculino");
    }

    @Test
    void testAtributosIniciais() {
        assertEquals("Luan", personagem.getNome());
        assertEquals(25, personagem.getIdade());
        assertEquals("Masculino", personagem.getSexo());
    }

    @Test
    void testAlterarNome() {
        personagem.setNome("Carlos");
        assertEquals("Carlos", personagem.getNome());
    }

    @Test
    void testConversar() {
        assertDoesNotThrow(() -> personagem.conversar());
    }

    @Test
    void testRefletirNaoGeraErro() {
        assertDoesNotThrow(() -> personagem.refletir());
    }
}
