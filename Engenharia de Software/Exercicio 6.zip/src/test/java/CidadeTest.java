import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CidadeTest {

    private Cidade cidade;

    @BeforeEach
    void setUp() {
        cidade = new Cidade("São Paulo", 12000000, -46.6333);
    }

    @Test
    void testAtributosIniciais() {
        assertEquals("São Paulo", cidade.getNome());
        assertEquals(12000000, cidade.getPopulacao());
        assertEquals(-46.6333, cidade.getLongitude());
    }

    @Test
    void testAlterarPopulacao() {
        cidade.setPopulacao(13000000);
        assertEquals(13000000, cidade.getPopulacao());
    }

    @Test
    void testMetodosNaoGeramErro() {
        assertDoesNotThrow(() -> cidade.coletarImpostos());
        assertDoesNotThrow(() -> cidade.organizar());
        assertDoesNotThrow(() -> cidade.limpar());
    }
}
